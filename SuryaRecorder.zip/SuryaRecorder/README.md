# SURYA RECORDER (com.suryarecorder)
Build: GitHub -> Actions -> "Build SURYA RECORDER APK" -> Run workflow -> download artifact "SuryaRecorder-debug-apk".
Android Studio: open this folder, Build > Build APK(s).

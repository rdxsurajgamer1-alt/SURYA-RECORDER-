package com.suryarecorder

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** A ScrollView that never grows taller than [maxH] (so the menu cannot cover the whole game). */
class MaxHeightScrollView(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

class SuryaService : Service() {

    companion object {
        const val ACTION_SHOW = "com.suryarecorder.SHOW"
        const val ACTION_EXIT = "com.suryarecorder.EXIT"
        const val ACTION_PROJ_OK = "com.suryarecorder.PROJ_OK"
        const val ACTION_PROJ_FAIL = "com.suryarecorder.PROJ_FAIL"
        const val ACTION_PAUSE_TOGGLE = "com.suryarecorder.PAUSE_TOGGLE"
        const val ACTION_STOP = "com.suryarecorder.STOP"
        const val ACTION_REFRESH = "com.suryarecorder.REFRESH"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        @Volatile var running = false
        /** 0 = stopped, 1 = recording, 2 = paused */
        @Volatile var state = 0

        private const val CHANNEL = "surya_channel"
        private const val NID = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: FrameLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var bubbleLogo: ImageView? = null
    private var bubbleTimer: TextView? = null

    private var menuHolder: FrameLayout? = null
    private var menuTimer: TextView? = null
    private var menuClosedAt = 0L

    private var areaOverlay: AreaOverlay? = null
    private var customDialog: View? = null
    private var countdownView: TextView? = null
    private var countdownRunnable: Runnable? = null

    private var recorder: ScreenRecorder? = null
    private var pendingProjection: MediaProjection? = null
    private var finishing = false
    private var exitWhenFinished = false

    private var locCtx: Context? = null
    private var locLang = ""

    // ------------------------------------------------------------ helpers

    private fun lc(): Context {
        val lang = prefs.lang
        if (locCtx == null || locLang != lang) {
            locCtx = LocaleHelper.wrap(applicationContext)
            locLang = lang
        }
        return locCtx!!
    }

    private fun t(id: Int, vararg a: Any): String = lc().getString(id, *a)

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun toast(s: String) = Toast.makeText(applicationContext, s, Toast.LENGTH_LONG).show()

    private fun screen(): IntArray {
        val dm = DisplayMetrics()
        val d = (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        d.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun micWanted(): Boolean =
        (prefs.audio == AudioMode.MIC || prefs.audio == AudioMode.BOTH) &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------ lifecycle

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        running = true
        state = 0
        val ch = NotificationChannel(CHANNEL, t(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        handler.postDelayed(ticker, 500)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_SHOW
        try { handleAction(action, intent) } catch (e: Throwable) {
            prefs.lastError = "Service: " + android.util.Log.getStackTraceString(e).take(1500)
            toast(t(R.string.rec_failed, e.message ?: e.toString()))
        }
        return START_NOT_STICKY
    }

    private fun handleAction(action: String, intent: Intent?) {
        when (action) {
            ACTION_EXIT -> handleExit()
            ACTION_PROJ_OK -> handleProjectionOk(intent)
            ACTION_PROJ_FAIL -> {
                ensureForeground()
                toast(t(R.string.perm_denied))
            }
            ACTION_PAUSE_TOGGLE -> togglePause()
            ACTION_STOP -> stopRecording()
            ACTION_REFRESH -> {
                ensureForeground()
                addBubble()
            }
            else -> { // ACTION_SHOW
                ensureForeground()
                addBubble()
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.post {
            areaOverlay?.dismiss(); areaOverlay = null
            closeMenu()
            clampBubble()
            bubble?.let { b -> bubbleParams?.let { p -> try { wm.updateViewLayout(b, p) } catch (e: Exception) { } } }
        }
    }

    override fun onDestroy() {
        running = false
        state = 0
        handler.removeCallbacksAndMessages(null)
        removeAllOverlays()
        recorder?.stop()
        recorder = null
        super.onDestroy()
    }

    private fun handleExit() {
        if (recorder != null) {
            exitWhenFinished = true
            stopRecording()
        } else if (finishing) {
            exitWhenFinished = true
        } else {
            shutdown()
        }
    }

    private fun shutdown() {
        removeAllOverlays()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------ foreground + notification

    private fun goForeground(proj: Boolean, mic: Boolean) {
        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                if (proj) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                if (proj && mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                startForeground(NID, n, type)
            } else if (proj) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                if (mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                startForeground(NID, n, type)
            } else {
                startForeground(NID, n)
            }
        } catch (e: Exception) {
            prefs.lastError = "Foreground service: $e"
            toast(t(R.string.rec_failed, e.message ?: "foreground service"))
        }
    }

    private fun ensureForeground() {
        val proj = state != 0 || pendingProjection != null
        goForeground(proj, proj && micWanted())
    }

    private fun buildNotification(): Notification {
        val text = when (state) {
            1 -> t(R.string.notif_text_rec)
            2 -> t(R.string.notif_text_paused)
            else -> t(R.string.notif_text_idle)
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_logo)
            .setContentTitle(t(R.string.app_name))
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
        fun act(label: String, action: String, code: Int) {
            val pi = PendingIntent.getService(
                this, code, Intent(this, SuryaService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_logo), label, pi).build())
        }
        if (state != 0) {
            act(if (state == 2) t(R.string.resume) else t(R.string.pause), ACTION_PAUSE_TOGGLE, 1)
            act(t(R.string.stop), ACTION_STOP, 2)
        } else {
            act(t(R.string.notif_exit), ACTION_EXIT, 3)
        }
        return b.build()
    }

    private fun updateNotification() {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NID, buildNotification())
    }

    // ------------------------------------------------------------ ticker (timer)

    private val ticker = object : Runnable {
        override fun run() {
            val r = recorder
            if (r != null && state != 0) {
                val s = Ui.fmtTime(r.elapsedMs())
                bubbleTimer?.text = if (state == 2) "II\n$s" else s
                menuTimer?.text = s
            }
            handler.postDelayed(this, 500)
        }
    }

    // ------------------------------------------------------------ bubble

    private fun clampBubble() {
        val p = bubbleParams ?: return
        val s = screen()
        val size = dp(prefs.bubbleSize)
        p.x = p.x.coerceIn(0, max(0, s[0] - size))
        p.y = p.y.coerceIn(0, max(0, s[1] - size))
    }

    private fun removeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble = null
        bubbleLogo = null
        bubbleTimer = null
    }

    private fun addBubble() {
        removeBubble()
        if (!prefs.bubbleVisible) return
        val size = dp(prefs.bubbleSize)
        val root = FrameLayout(this)
        root.setBackgroundResource(R.drawable.bg_bubble)
        root.alpha = prefs.bubbleOpacity / 100f

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val timer = Ui.text(this, "00:00", 11f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        root.addView(logo, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        root.addView(timer, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))

        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = if (prefs.bubbleX >= 0) prefs.bubbleX else dp(8)
        lp.y = if (prefs.bubbleY >= 0) prefs.bubbleY else dp(150)

        val slop = dp(8)
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        root.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        clampBubble()
                        try { wm.updateViewLayout(root, lp) } catch (e: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.bubbleX = lp.x
                        prefs.bubbleY = lp.y
                    } else {
                        toggleMenu()
                    }
                }
            }
            true
        }

        try {
            clampBubbleFor(lp, size)
            wm.addView(root, lp)
        } catch (e: Exception) {
            prefs.lastError = "Bubble: $e"
            toast(t(R.string.need_overlay))
            return
        }
        bubble = root
        bubbleParams = lp
        bubbleLogo = logo
        bubbleTimer = timer
        updateBubbleUi()
    }

    private fun clampBubbleFor(lp: WindowManager.LayoutParams, size: Int) {
        val s = screen()
        lp.x = lp.x.coerceIn(0, max(0, s[0] - size))
        lp.y = lp.y.coerceIn(0, max(0, s[1] - size))
    }

    private fun updateBubbleUi() {
        val b = bubble ?: return
        if (state == 0) {
            bubbleLogo?.visibility = View.VISIBLE
            bubbleTimer?.visibility = View.GONE
            b.setBackgroundResource(R.drawable.bg_bubble)
        } else {
            bubbleLogo?.visibility = View.GONE
            bubbleTimer?.visibility = View.VISIBLE
            b.setBackgroundResource(R.drawable.bg_bubble_rec)
        }
        b.visibility = if (state != 0 && prefs.hideWhileRecording) View.GONE else View.VISIBLE
    }

    private fun updateAllUi() {
        updateBubbleUi()
        if (menuHolder != null) refreshMenu()
        updateNotification()
    }

    // ------------------------------------------------------------ floating menu

    private fun toggleMenu() {
        if (menuHolder != null) {
            closeMenu()
        } else if (SystemClock.uptimeMillis() - menuClosedAt > 350 && areaOverlay == null && customDialog == null) {
            openMenu()
        }
    }

    private fun openMenu() {
        if (menuHolder != null) return
        val holder = FrameLayout(this)
        holder.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_OUTSIDE) closeMenu()
            false
        }
        holder.addView(buildMenu())
        val s = screen()
        val land = s[0] > s[1]
        val w = if (land) min((s[0] * 0.85f).toInt(), dp(600)) else min((s[0] * 0.92f).toInt(), dp(360))
        val lp = WindowManager.LayoutParams(
            w, Ui.WRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        try {
            wm.addView(holder, lp)
            menuHolder = holder
        } catch (e: Exception) {
            toast(t(R.string.need_overlay))
        }
    }

    private fun closeMenu() {
        menuHolder?.let {
            try { wm.removeView(it) } catch (e: Exception) { }
            menuClosedAt = SystemClock.uptimeMillis()
        }
        menuHolder = null
        menuTimer = null
    }

    private fun refreshMenu() {
        val h = menuHolder ?: return
        h.removeAllViews()
        h.addView(buildMenu())
    }

    private fun buildMenu(): View {
        val c: Context = this
        val s = screen()
        val land = s[0] > s[1]
        val p = dp(12)
        val orange = getColor(R.color.orange)

        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(p, p, p, p)
        }

        // header: name + status
        val head = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(Ui.text(c, "SURYA RECORDER", 15f, orange, true), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        val stText = when (state) {
            1 -> "● " + t(R.string.st_recording)
            2 -> "❚❚ " + t(R.string.st_paused)
            else -> "■ " + t(R.string.st_idle)
        }
        head.addView(Ui.text(c, stText, 13f, if (state == 1) getColor(R.color.red) else getColor(R.color.text_dim), true))
        card.addView(head)

        // timer
        val elapsed = recorder?.elapsedMs() ?: 0L
        val tt = Ui.text(c, Ui.fmtTime(elapsed), 28f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        menuTimer = tt
        card.addView(tt, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        // controls
        fun ctl(label: String, bg: Int, enabled: Boolean, color: Int, click: () -> Unit): TextView {
            val b = Ui.button(c, label, bg, 14f, 48)
            b.layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
            b.setTextColor(color)
            b.isEnabled = enabled
            b.alpha = if (enabled) 1f else 0.35f
            b.setOnClickListener { click() }
            return b
        }
        val controls = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(ctl("● " + t(R.string.record), R.drawable.bg_btn_orange, state == 0, Color.BLACK) { onRecordClicked() })
        controls.addView(
            ctl(if (state == 2) "▶ " + t(R.string.resume) else "❚❚ " + t(R.string.pause), R.drawable.bg_btn_dark, state != 0, Color.WHITE) { togglePause() }
        )
        controls.addView(ctl("■ " + t(R.string.stop), R.drawable.bg_btn_red, state != 0, Color.WHITE) { stopRecording() })
        card.addView(controls)

        if (state == 0) {
            val left = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            val right = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            val l = left
            val r = if (land) right else left

            // video size
            l.addView(Ui.section(c, t(R.string.video_size)))
            val ratioLabels = listOf(
                t(R.string.full_screen), t(R.string.ratio_portrait), t(R.string.ratio_landscape),
                t(R.string.ratio_square), t(R.string.ratio_43), t(R.string.custom)
            )
            l.addView(Ui.chips(c, ratioLabels, Ratio.ALL.indexOf(prefs.ratio).coerceAtLeast(0), 3) { idx ->
                val key = Ratio.ALL[idx]
                prefs.ratio = key
                when (key) {
                    Ratio.CUSTOM -> showCustomDialog()
                    Ratio.FULL -> refreshMenu()
                    else -> startAreaSelect()
                }
            })
            if (prefs.ratio != Ratio.FULL) {
                val b = Ui.button(c, "▢ " + t(R.string.select_area), R.drawable.bg_btn_dark, 13f, 42)
                b.layoutParams = LinearLayout.LayoutParams(Ui.MATCH, dp(42)).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
                b.setOnClickListener { startAreaSelect() }
                l.addView(b)
            }

            // resolution
            val resVals = listOf(720, 1080, 1440, 2160)
            l.addView(Ui.section(c, t(R.string.resolution)))
            l.addView(Ui.chips(c, listOf("720p HD", "1080p FHD", "2K 1440p", "4K 2160p"), resVals.indexOf(prefs.resolution).coerceAtLeast(0), 2) {
                prefs.resolution = resVals[it]
                warnAboutPlan()
            })

            // fps
            val fpsVals = listOf(30, 60, 90)
            l.addView(Ui.section(c, t(R.string.fps)))
            l.addView(Ui.chips(c, listOf("30", "60", "90"), fpsVals.indexOf(prefs.fps).coerceAtLeast(0), 3) {
                prefs.fps = fpsVals[it]
                warnAboutPlan()
            })

            // audio
            r.addView(Ui.section(c, t(R.string.audio_settings)))
            r.addView(
                Ui.chips(
                    c,
                    listOf(t(R.string.audio_internal), t(R.string.audio_mic), t(R.string.audio_both), t(R.string.audio_none)),
                    AudioMode.ALL.indexOf(prefs.audio).coerceAtLeast(0), 1
                ) { prefs.audio = AudioMode.ALL[it] }
            )

            // bottom buttons
            val bottom = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            val bs = Ui.button(c, "⚙ " + t(R.string.settings), R.drawable.bg_btn_dark, 13f, 44)
            bs.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), dp(8), dp(3), dp(3)) }
            bs.setOnClickListener {
                closeMenu()
                startActivity(Intent(c, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            val bc = Ui.button(c, "✕ " + t(R.string.close_bubble), R.drawable.bg_btn_red, 13f, 44)
            bc.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), dp(8), dp(3), dp(3)) }
            bc.setOnClickListener { handleExit() }
            bottom.addView(bs)
            bottom.addView(bc)
            r.addView(bottom)

            if (land) {
                val two = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
                two.addView(left, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginEnd = dp(6) })
                two.addView(right, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginStart = dp(6) })
                card.addView(two)
            } else {
                card.addView(left)
            }
        }

        val scroll = MaxHeightScrollView(c, (s[1] * 0.92f).toInt())
        scroll.addView(card, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        return scroll
    }

    // ------------------------------------------------------------ custom size dialog

    private fun showCustomDialog() {
        closeMenu()
        if (customDialog != null) return
        val c: Context = this
        val s = screen()
        val p = dp(14)
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(p, p, p, p)
        }
        card.addView(Ui.text(c, t(R.string.custom_title), 15f, getColor(R.color.orange), true))
        val etW = EditText(c).apply {
            hint = t(R.string.width)
            setText(prefs.customW.toString())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE)
            setHintTextColor(getColor(R.color.text_dim))
        }
        val etH = EditText(c).apply {
            hint = t(R.string.height)
            setText(prefs.customH.toString())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE)
            setHintTextColor(getColor(R.color.text_dim))
        }
        val fields = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        fields.addView(etW, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        fields.addView(etH, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        card.addView(fields)

        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val cancel = Ui.button(c, t(R.string.cancel), R.drawable.bg_btn_dark, 14f, 46)
        val ok = Ui.button(c, t(R.string.ok), R.drawable.bg_btn_orange, 14f, 46)
        ok.setTextColor(Color.BLACK)
        cancel.layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(0, dp(8), dp(4), 0) }
        ok.layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(4), dp(8), 0, 0) }
        row.addView(cancel)
        row.addView(ok)
        card.addView(row)

        val lp = WindowManager.LayoutParams(
            min((s[0] * 0.9f).toInt(), dp(360)), Ui.WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            0, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(30)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN

        fun close() {
            customDialog?.let { try { wm.removeView(it) } catch (e: Exception) { } }
            customDialog = null
        }
        cancel.setOnClickListener { close(); openMenu() }
        ok.setOnClickListener {
            val w = etW.text.toString().toIntOrNull() ?: 0
            val h = etH.text.toString().toIntOrNull() ?: 0
            if (w in 100..4096 && h in 100..4096) {
                prefs.customW = w
                prefs.customH = h
                close()
                startAreaSelect()
            } else {
                toast(t(R.string.custom_invalid))
            }
        }
        try {
            wm.addView(card, lp)
            customDialog = card
        } catch (e: Exception) {
            toast(t(R.string.need_overlay))
        }
    }

    // ------------------------------------------------------------ area selection

    private fun startAreaSelect() {
        if (areaOverlay != null) return
        closeMenu()
        val s = screen()
        val sw = s[0]
        val sh = s[1]
        val aspect = prefs.aspect()
        val custom = prefs.ratio == Ratio.CUSTOM
        val init = prefs.loadArea(sw, sh)
            ?: Prefs.defaultArea(aspect, sw, sh, if (custom) prefs.customW else 0, if (custom) prefs.customH else 0)
        val ov = AreaOverlay(
            this, wm, sw, sh, aspect, init,
            t(R.string.area_hint), t(R.string.ok), t(R.string.cancel)
        ) { rect ->
            areaOverlay = null
            if (rect != null) prefs.saveArea(rect, sw, sh)
            openMenu()
        }
        areaOverlay = ov
        try {
            ov.show()
        } catch (e: Exception) {
            areaOverlay = null
            toast(t(R.string.need_overlay))
        }
    }

    // ------------------------------------------------------------ plan / warnings

    private fun regionNow(sw: Int, sh: Int): Pair<Rect, Boolean> {
        if (prefs.ratio == Ratio.FULL) return Pair(Rect(0, 0, sw, sh), false)
        val saved = prefs.loadArea(sw, sh)
        if (saved != null) return Pair(saved, false)
        val stale = prefs.areaStale(sw, sh)
        val custom = prefs.ratio == Ratio.CUSTOM
        val r = Prefs.defaultArea(prefs.aspect(), sw, sh, if (custom) prefs.customW else 0, if (custom) prefs.customH else 0)
        return Pair(r, stale)
    }

    private fun planFor(sw: Int, sh: Int, region: Rect): ScreenRecorder.Plan =
        ScreenRecorder.makePlan(this, sw, sh, region, prefs.resolution, prefs.fps)

    private fun showPlanWarnings(plan: ScreenRecorder.Plan) {
        if (plan.resWarn) {
            toast(t(R.string.warn_res, ScreenRecorder.levelName(plan.reqLevel), ScreenRecorder.levelName(plan.level)))
        }
        if (plan.fpsWarn) {
            toast(t(R.string.warn_fps, plan.reqFps, plan.fps))
        }
    }

    /** Called when the user picks a resolution / FPS in the menu. */
    private fun warnAboutPlan() {
        val s = screen()
        val region = regionNow(s[0], s[1]).first
        showPlanWarnings(planFor(s[0], s[1], region))
        refreshMenu()
    }

    // ------------------------------------------------------------ recording flow

    private fun onRecordClicked() {
        if (state != 0 || pendingProjection != null) return
        closeMenu()
        try {
            startActivity(
                Intent(this, ProjectionActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        } catch (e: Exception) {
            toast(t(R.string.rec_failed, e.message ?: ""))
        }
    }

    @Suppress("DEPRECATION")
    private fun handleProjectionOk(intent: Intent?) {
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        // The foreground service must have the media-projection type BEFORE we use the permission.
        goForeground(true, micWanted())
        if (data == null) {
            toast(t(R.string.perm_denied))
            goForeground(false, false)
            return
        }
        val mp = try {
            (getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code, data)
        } catch (e: Exception) {
            toast(t(R.string.rec_failed, e.message ?: ""))
            null
        }
        if (mp == null) {
            goForeground(false, false)
            return
        }
        beginCountdown(mp)
    }

    private fun beginCountdown(mp: MediaProjection) {
        pendingProjection = mp
        val n = prefs.countdown
        if (n <= 0) {
            startRecording(mp)
            pendingProjection = null
            return
        }
        val tv = Ui.text(this, n.toString(), 90f, getColor(R.color.orange), true).apply {
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_bubble)
            setOnClickListener { cancelCountdown() }
        }
        val lp = WindowManager.LayoutParams(
            dp(170), dp(170), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        try {
            wm.addView(tv, lp)
            countdownView = tv
        } catch (e: Exception) {
        }
        var left = n
        val r = object : Runnable {
            override fun run() {
                left--
                if (left > 0) {
                    tv.text = left.toString()
                    handler.postDelayed(this, 1000)
                } else {
                    removeCountdown()
                    val m = pendingProjection
                    pendingProjection = null
                    if (m != null) handler.postDelayed({ startRecording(m) }, 250)
                }
            }
        }
        countdownRunnable = r
        handler.postDelayed(r, 1000)
    }

    private fun removeCountdown() {
        countdownRunnable?.let { handler.removeCallbacks(it) }
        countdownRunnable = null
        countdownView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        countdownView = null
    }

    private fun cancelCountdown() {
        removeCountdown()
        try { pendingProjection?.stop() } catch (e: Exception) { }
        pendingProjection = null
        goForeground(false, false)
    }

    private fun startRecording(mp: MediaProjection) {
        val s = screen()
        val sw = s[0]
        val sh = s[1]
        val (region, reset) = regionNow(sw, sh)
        if (reset) toast(t(R.string.warn_area_reset))
        val plan = planFor(sw, sh, region)
        showPlanWarnings(plan)

        val cfg = ScreenRecorder.Config(sw, sh, s[2], region, plan, prefs.audio, prefs.saveLocation == "dcim")
        val rec = ScreenRecorder(applicationContext, mp, cfg, recorderListener)
        try {
            rec.start()
        } catch (e: Throwable) {
            rec.abort()
            try { mp.stop() } catch (x: Exception) { }
            toast(t(R.string.rec_failed, e.message ?: e.toString()))
            goForeground(false, false)
            return
        }
        recorder = rec
        state = 1
        toast(t(R.string.rec_started))
        updateAllUi()
    }

    private fun togglePause() {
        val r = recorder ?: return
        if (r.paused) {
            r.resume()
            state = 1
        } else {
            r.pause()
            state = 2
        }
        updateAllUi()
    }

    private fun stopRecording() {
        val r = recorder ?: return
        recorder = null
        state = 0
        finishing = true
        r.stop()
        updateAllUi()
    }

    private val recorderListener = object : ScreenRecorder.Listener {
        override fun onWarning(code: Int) {
            when (code) {
                ScreenRecorder.W_INTERNAL -> toast(t(R.string.warn_internal))
                ScreenRecorder.W_MIC -> toast(t(R.string.warn_mic))
                ScreenRecorder.W_NOAUDIO -> toast(t(R.string.warn_audio_none))
            }
        }

        override fun onProjectionStopped() {
            // The user stopped sharing from the Android status bar chip.
            stopRecording()
        }

        override fun onFinished(uri: Uri?, name: String) {
            finishing = false
            if (uri != null) toast(t(R.string.saved, name)) else toast(t(R.string.save_failed))
            if (exitWhenFinished) {
                shutdown()
            } else if (state == 0 && recorder == null) {
                goForeground(false, false)
                updateAllUi()
            }
        }
    }

    // ------------------------------------------------------------ cleanup

    private fun removeAllOverlays() {
        removeCountdown()
        areaOverlay?.dismiss()
        areaOverlay = null
        customDialog?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        customDialog = null
        closeMenu()
        removeBubble()
    }
}

package com.suryarecorder

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.format.Formatter
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class RecordingsActivity : Activity() {

    private lateinit var list: LinearLayout

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = Ui.dp(this, 16)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad * 2)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(getColor(R.color.bg))
            addView(list, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private class Item(
        val id: Long, val name: String, val duration: Long,
        val w: Int, val h: Int, val size: Long
    )

    private fun query(): List<Item> {
        val out = ArrayList<Item>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT, MediaStore.Video.Media.SIZE
        )
        val sel = "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?"
        val args = arrayOf("Movies/SuryaRecorder%", "DCIM/SuryaRecorder%")
        try {
            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, sel, args,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    out.add(Item(c.getLong(0), c.getString(1) ?: "video.mp4", c.getLong(2), c.getInt(3), c.getInt(4), c.getLong(5)))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun uriOf(id: Long): Uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)

    private fun load() {
        list.removeAllViews()
        list.addView(Ui.text(this, getString(R.string.recordings), 24f, getColor(R.color.orange), true))
        val items = query()
        if (items.isEmpty()) {
            list.addView(Ui.text(this, getString(R.string.no_recordings), 16f, getColor(R.color.text_dim)).apply {
                setPadding(0, Ui.dp(this@RecordingsActivity, 40), 0, 0)
            })
            return
        }
        for (it in items) list.addView(card(it))
    }

    private fun card(item: Item): LinearLayout {
        val p = Ui.dp(this, 12)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(this@RecordingsActivity, 12) }
        }
        card.addView(Ui.text(this, item.name, 15f, Color.WHITE, true))
        val info = "${Ui.fmtTime(item.duration)}  •  ${item.w}×${item.h}  •  ${Formatter.formatFileSize(this, item.size)}"
        card.addView(Ui.text(this, info, 13f, getColor(R.color.text_dim)).apply {
            setPadding(0, Ui.dp(this@RecordingsActivity, 4), 0, Ui.dp(this@RecordingsActivity, 8))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun b(label: String, bg: Int, click: () -> Unit) {
            val btn = Ui.button(this, label, bg, 12f, 40)
            btn.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply {
                setMargins(Ui.dp(this@RecordingsActivity, 2), 0, Ui.dp(this@RecordingsActivity, 2), 0)
            }
            btn.setOnClickListener { click() }
            row.addView(btn)
        }
        b(getString(R.string.play), R.drawable.bg_btn_orange) { play(item) }
        b(getString(R.string.rename), R.drawable.bg_btn_dark) { rename(item) }
        b(getString(R.string.share), R.drawable.bg_btn_dark) { share(item) }
        b(getString(R.string.delete), R.drawable.bg_btn_red) { delete(item) }
        card.addView(row)
        return card
    }

    private fun play(item: Item) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uriOf(item.id), "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            Toast.makeText(this, R.string.no_player, Toast.LENGTH_SHORT).show()
        }
    }

    private fun share(item: Item) {
        val i = Intent(Intent.ACTION_SEND).setType("video/mp4")
            .putExtra(Intent.EXTRA_STREAM, uriOf(item.id))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, getString(R.string.share)))
    }

    private fun rename(item: Item) {
        val et = EditText(this).apply { setText(item.name.removeSuffix(".mp4")) }
        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(et)
            .setPositiveButton(R.string.ok) { _, _ ->
                val n = et.text.toString().trim().replace("/", "_")
                if (n.isNotEmpty()) {
                    try {
                        val v = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "$n.mp4") }
                        contentResolver.update(uriOf(item.id), v, null, null)
                    } catch (e: Exception) {
                        Toast.makeText(this, R.string.rename_failed, Toast.LENGTH_LONG).show()
                    }
                    load()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun delete(item: Item) {
        AlertDialog.Builder(this)
            .setMessage(R.string.delete_confirm)
            .setPositiveButton(R.string.delete) { _, _ ->
                try {
                    val n = contentResolver.delete(uriOf(item.id), null, null)
                    if (n > 0) Toast.makeText(this, R.string.deleted, Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, R.string.delete_failed, Toast.LENGTH_LONG).show()
                }
                load()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}

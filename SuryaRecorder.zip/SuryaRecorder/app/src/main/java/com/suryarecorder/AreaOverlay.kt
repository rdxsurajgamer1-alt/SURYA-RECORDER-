package com.suryarecorder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** The draggable box: it dims everything outside, can be moved, and resized from the corner dot. */
class AreaView(ctx: Context, private val aspect: Float) : View(ctx) {
    val box = RectF()
    private val orange = Color.parseColor("#FF7A00")
    private val dim = Paint().apply { color = 0xAA000000.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = orange; style = Paint.Style.STROKE; strokeWidth = Ui.dp(ctx, 3).toFloat()
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = orange }
    private val dotRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = Ui.dp(ctx, 2).toFloat()
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = Ui.dp(ctx, 13).toFloat()
    }
    private val dotR = Ui.dp(ctx, 14).toFloat()
    private val grab = Ui.dp(ctx, 44).toFloat()
    private val minW = Ui.dp(ctx, 100).toFloat()

    private var mode = 0 // 0 none, 1 move, 2 resize
    private var lastX = 0f
    private var lastY = 0f

    override fun onDraw(c: Canvas) {
        c.save()
        c.clipOutRect(box)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        c.restore()
        c.drawRect(box, border)
        c.drawCircle(box.right, box.bottom, dotR, dot)
        c.drawCircle(box.right, box.bottom, dotR, dotRing)
        c.drawText("${box.width().roundToInt()} × ${box.height().roundToInt()}", box.left + 12f, box.top + label.textSize + 8f, label)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = when {
                    hypot(e.x - box.right, e.y - box.bottom) < grab -> 2
                    box.contains(e.x, e.y) -> 1
                    else -> 0
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                val dy = e.y - lastY
                lastX = e.x; lastY = e.y
                if (mode == 1) {
                    val nl = (box.left + dx).coerceIn(0f, max(0f, width - box.width()))
                    val nt = (box.top + dy).coerceIn(0f, max(0f, height - box.height()))
                    box.offsetTo(nl, nt)
                } else if (mode == 2) {
                    val maxW = min(width - box.left, (height - box.top) * aspect)
                    val nw = (e.x - box.left).coerceIn(min(minW, maxW), maxW)
                    box.right = box.left + nw
                    box.bottom = box.top + nw / aspect
                }
                invalidate()
            }
        }
        return true
    }
}

/**
 * Full-screen overlay used to choose the recording area.
 * [initial] and the result are in real screen pixels.
 */
class AreaOverlay(
    private val ctx: Context,
    private val wm: WindowManager,
    private val screenW: Int,
    private val screenH: Int,
    private val aspect: Float,
    private val initial: Rect,
    hint: String,
    okText: String,
    cancelText: String,
    private val onResult: (Rect?) -> Unit
) {
    private val root = FrameLayout(ctx)
    private val areaView = AreaView(ctx, aspect)
    private var shown = false

    init {
        root.addView(areaView, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))

        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 10), Ui.dp(ctx, 12), Ui.dp(ctx, 12))
        }
        val tv = Ui.text(ctx, hint, 13f, Color.WHITE).apply { gravity = Gravity.CENTER }
        bar.addView(tv, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val cancel = Ui.button(ctx, cancelText, R.drawable.bg_btn_dark, 15f, 52)
        val ok = Ui.button(ctx, okText, R.drawable.bg_btn_orange, 16f, 52)
        ok.setTextColor(Color.BLACK)
        cancel.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(ctx, 52), 1f).apply { setMargins(0, Ui.dp(ctx, 8), Ui.dp(ctx, 6), 0) }
        ok.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(ctx, 52), 1f).apply { setMargins(Ui.dp(ctx, 6), Ui.dp(ctx, 8), 0, 0) }
        row.addView(cancel)
        row.addView(ok)
        bar.addView(row, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        val barW = min(Ui.dp(ctx, 360), (screenW * 0.9f).toInt())
        root.addView(bar, FrameLayout.LayoutParams(barW, Ui.WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = Ui.dp(ctx, 16)
        })

        cancel.setOnClickListener { finish(null) }
        ok.setOnClickListener {
            val loc = IntArray(2)
            root.getLocationOnScreen(loc)
            val b = areaView.box
            val l = (b.left.roundToInt() + loc[0]).coerceIn(0, screenW)
            val t = (b.top.roundToInt() + loc[1]).coerceIn(0, screenH)
            val r = (b.right.roundToInt() + loc[0]).coerceIn(0, screenW)
            val bt = (b.bottom.roundToInt() + loc[1]).coerceIn(0, screenH)
            finish(Rect(l, t, max(r, l + 50), max(bt, t + 50)))
        }
    }

    fun show() {
        val lp = WindowManager.LayoutParams(
            screenW, screenH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(root, lp)
        shown = true
        root.post {
            // convert the initial (screen) box to view coordinates
            val loc = IntArray(2)
            root.getLocationOnScreen(loc)
            areaView.box.set(
                (initial.left - loc[0]).toFloat(), (initial.top - loc[1]).toFloat(),
                (initial.right - loc[0]).toFloat(), (initial.bottom - loc[1]).toFloat()
            )
            areaView.invalidate()
        }
    }

    fun dismiss() {
        if (shown) {
            try { wm.removeView(root) } catch (e: Exception) { }
            shown = false
        }
    }

    private fun finish(r: Rect?) {
        dismiss()
        onResult(r)
    }
}

package com.suryarecorder

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        build()
    }

    private fun notifyService() {
        if (SuryaService.running) {
            startService(Intent(this, SuryaService::class.java).setAction(SuryaService.ACTION_REFRESH))
        }
    }

    private fun build() {
        val pad = Ui.dp(this, 16)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad * 2)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(getColor(R.color.bg))
            addView(col, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        }
        setContentView(scroll)

        col.addView(Ui.text(this, getString(R.string.settings), 24f, getColor(R.color.orange), true))

        // Audio source
        col.addView(Ui.section(this, getString(R.string.audio_source_settings)))
        col.addView(
            Ui.chips(
                this,
                listOf(R.string.audio_internal, R.string.audio_mic, R.string.audio_both, R.string.audio_none)
                    .map { getString(it) },
                AudioMode.ALL.indexOf(prefs.audio).coerceAtLeast(0), 1
            ) { prefs.audio = AudioMode.ALL[it] }
        )

        // Resolution
        val resVals = listOf(720, 1080, 1440, 2160)
        col.addView(Ui.section(this, getString(R.string.default_resolution)))
        col.addView(
            Ui.chips(
                this, listOf("720p HD", "1080p Full HD", "2K (1440p)", "4K (2160p)"),
                resVals.indexOf(prefs.resolution).coerceAtLeast(0), 2
            ) { prefs.resolution = resVals[it] }
        )

        // FPS
        val fpsVals = listOf(30, 60, 90)
        col.addView(Ui.section(this, getString(R.string.default_fps)))
        col.addView(
            Ui.chips(
                this, listOf("30 FPS", "60 FPS", "90 FPS"),
                fpsVals.indexOf(prefs.fps).coerceAtLeast(0), 3
            ) { prefs.fps = fpsVals[it] }
        )

        // Ratio
        col.addView(Ui.section(this, getString(R.string.default_ratio)))
        val ratioLabels = listOf(
            getString(R.string.full_screen), getString(R.string.ratio_portrait),
            getString(R.string.ratio_landscape), getString(R.string.ratio_square),
            getString(R.string.ratio_43), getString(R.string.custom)
        )
        col.addView(
            Ui.chips(this, ratioLabels, Ratio.ALL.indexOf(prefs.ratio).coerceAtLeast(0), 2) {
                prefs.ratio = Ratio.ALL[it]
            }
        )
        // Custom width / height
        val customRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val etW = numberField(getString(R.string.width), prefs.customW)
        val etH = numberField(getString(R.string.height), prefs.customH)
        etW.addTextChangedListener(watch { v -> if (v in 100..4096) prefs.customW = v })
        etH.addTextChangedListener(watch { v -> if (v in 100..4096) prefs.customH = v })
        customRow.addView(etW, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        customRow.addView(etH, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        col.addView(Ui.text(this, getString(R.string.custom_title), 12f, getColor(R.color.text_dim)))
        col.addView(customRow)

        // Floating button
        col.addView(Ui.section(this, getString(R.string.float_button)))
        col.addView(
            Ui.chips(
                this, listOf(getString(R.string.show), getString(R.string.hide)),
                if (prefs.bubbleVisible) 0 else 1, 2
            ) { prefs.bubbleVisible = (it == 0); notifyService() }
        )

        col.addView(Ui.section(this, getString(R.string.float_size)))
        val sizeLabel = Ui.text(this, "${prefs.bubbleSize} dp", 12f, getColor(R.color.text_dim))
        col.addView(sizeLabel)
        col.addView(seek(36, 90, prefs.bubbleSize) { v, done ->
            sizeLabel.text = "$v dp"
            if (done) { prefs.bubbleSize = v; notifyService() }
        })

        col.addView(Ui.section(this, getString(R.string.float_opacity)))
        val opLabel = Ui.text(this, "${prefs.bubbleOpacity}%", 12f, getColor(R.color.text_dim))
        col.addView(opLabel)
        col.addView(seek(30, 100, prefs.bubbleOpacity) { v, done ->
            opLabel.text = "$v%"
            if (done) { prefs.bubbleOpacity = v; notifyService() }
        })

        val sw = Switch(this).apply {
            text = getString(R.string.hide_while_rec)
            setTextColor(Color.WHITE)
            isChecked = prefs.hideWhileRecording
            setPadding(0, Ui.dp(this@SettingsActivity, 10), 0, Ui.dp(this@SettingsActivity, 10))
            setOnCheckedChangeListener { _, c -> prefs.hideWhileRecording = c }
        }
        col.addView(sw)

        // Countdown
        val cdVals = listOf(0, 3, 5)
        col.addView(Ui.section(this, getString(R.string.countdown)))
        col.addView(
            Ui.chips(
                this,
                listOf(getString(R.string.off), getString(R.string.seconds_fmt, 3), getString(R.string.seconds_fmt, 5)),
                cdVals.indexOf(prefs.countdown).coerceAtLeast(0), 3
            ) { prefs.countdown = cdVals[it] }
        )

        // Save location
        col.addView(Ui.section(this, getString(R.string.save_location)))
        col.addView(
            Ui.chips(
                this, listOf(getString(R.string.loc_movies), getString(R.string.loc_dcim)),
                if (prefs.saveLocation == "dcim") 1 else 0, 1
            ) { prefs.saveLocation = if (it == 1) "dcim" else "movies" }
        )

        // Format
        col.addView(Ui.section(this, getString(R.string.video_format)))
        col.addView(Ui.text(this, getString(R.string.mp4_only), 14f, Color.WHITE))

        // Language
        col.addView(Ui.section(this, getString(R.string.language)))
        col.addView(
            Ui.chips(
                this, listOf(getString(R.string.lang_hi), getString(R.string.lang_en)),
                if (prefs.lang == "en") 1 else 0, 2
            ) {
                prefs.lang = if (it == 1) "en" else "hi"
                notifyService()
                recreate()
            }
        )
    }

    private fun numberField(hintText: String, value: Int): EditText = EditText(this).apply {
        hint = hintText
        setText(value.toString())
        inputType = InputType.TYPE_CLASS_NUMBER
        setTextColor(Color.WHITE)
        setHintTextColor(getColor(R.color.text_dim))
    }

    private fun watch(onValue: (Int) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
            s?.toString()?.toIntOrNull()?.let(onValue)
        }
    }

    private fun seek(min: Int, max: Int, value: Int, cb: (Int, Boolean) -> Unit): SeekBar =
        SeekBar(this).apply {
            this.max = max - min
            progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) cb(p + min, false)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    cb((s?.progress ?: 0) + min, true)
                }
            })
        }
}

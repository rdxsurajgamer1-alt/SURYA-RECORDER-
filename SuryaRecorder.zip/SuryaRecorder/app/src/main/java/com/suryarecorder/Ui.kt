package com.suryarecorder

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Small helpers so all screens (and the floating menu) look the same. */
object Ui {
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun text(ctx: Context, s: String, sp: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun section(ctx: Context, s: String): TextView =
        text(ctx, s, 13f, ctx.getColor(R.color.orange), true).apply {
            setPadding(dp(ctx, 4), dp(ctx, 10), 0, dp(ctx, 2))
        }

    fun button(
        ctx: Context, label: String, bg: Int = R.drawable.bg_btn_dark,
        sp: Float = 14f, hDp: Int = 46
    ): Button = Button(ctx).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = sp
        setBackgroundResource(bg)
        stateListAnimator = null
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        gravity = Gravity.CENTER
        setPadding(dp(ctx, 8), 0, dp(ctx, 8), 0)
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(ctx, hDp))
    }

    /** A grid of selectable buttons. The selected one is orange. */
    fun chips(
        ctx: Context, labels: List<String>, selected: Int, cols: Int,
        onPick: (Int) -> Unit
    ): LinearLayout {
        val column = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val btns = ArrayList<Button>()
        fun paint(sel: Int) {
            btns.forEachIndexed { i, b ->
                b.setBackgroundResource(if (i == sel) R.drawable.bg_btn_orange else R.drawable.bg_btn_dark)
                b.setTextColor(if (i == sel) Color.BLACK else Color.WHITE)
            }
        }
        val m = dp(ctx, 3)
        var i = 0
        while (i < labels.size) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until cols) {
                val idx = i + c
                val lp = LinearLayout.LayoutParams(0, dp(ctx, 42), 1f).apply { setMargins(m, m, m, m) }
                if (idx < labels.size) {
                    val b = button(ctx, labels[idx], sp = 13f, hDp = 42)
                    b.layoutParams = lp
                    b.setOnClickListener { paint(idx); onPick(idx) }
                    btns.add(b)
                    row.addView(b)
                } else {
                    row.addView(View(ctx), lp)
                }
            }
            column.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            i += cols
        }
        paint(selected)
        return column
    }

    fun fmtTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }
}

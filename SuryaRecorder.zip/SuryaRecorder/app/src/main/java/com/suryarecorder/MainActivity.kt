package com.suryarecorder

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnStopBubble: Button
    private val handler = Handler(Looper.getMainLooper())
    private var langAtCreate = ""
    private val refresher = object : Runnable {
        override fun run() {
            refreshUi()
            handler.postDelayed(this, 500)
        }
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        langAtCreate = Prefs(this).lang
        setContentView(R.layout.activity_main)
        tvStatus = findViewById(R.id.tvStatus)
        btnStopBubble = findViewById(R.id.btnStopBubble)

        findViewById<Button>(R.id.btnStart).setOnClickListener { onStartPressed() }
        btnStopBubble.setOnClickListener {
            startService(Intent(this, SuryaService::class.java).setAction(SuryaService.ACTION_EXIT))
            Toast.makeText(this, R.string.bubble_closed, Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnRecordings).setOnClickListener {
            startActivity(Intent(this, RecordingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        if (Prefs(this).lang != langAtCreate) {
            recreate()
            return
        }
        handler.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refresher)
    }

    private fun refreshUi() {
        val st = when (SuryaService.state) {
            1 -> getString(R.string.st_recording)
            2 -> getString(R.string.st_paused)
            else -> getString(R.string.st_idle)
        }
        tvStatus.text = getString(R.string.status) + ": " + st
        btnStopBubble.visibility = if (SuryaService.running) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun onStartPressed() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 10)
            return
        }
        launchBubble()
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, R.string.need_mic, Toast.LENGTH_LONG).show()
            }
            launchBubble()
        }
    }

    private fun launchBubble() {
        Prefs(this).bubbleVisible = true
        startForegroundService(Intent(this, SuryaService::class.java).setAction(SuryaService.ACTION_SHOW))
        Toast.makeText(this, R.string.bubble_started, Toast.LENGTH_SHORT).show()
        moveTaskToBack(true)
    }
}

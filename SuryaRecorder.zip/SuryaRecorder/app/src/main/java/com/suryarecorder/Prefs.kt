package com.suryarecorder

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Rect
import java.util.Locale

object Ratio {
    const val FULL = "full"
    const val R916 = "9:16"
    const val R169 = "16:9"
    const val R11 = "1:1"
    const val R43 = "4:3"
    const val CUSTOM = "custom"
    val ALL = listOf(FULL, R916, R169, R11, R43, CUSTOM)
}

object AudioMode {
    const val INTERNAL = "internal"
    const val MIC = "mic"
    const val BOTH = "both"
    const val NONE = "none"
    val ALL = listOf(INTERNAL, MIC, BOTH, NONE)
}

class Prefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("surya_prefs", Context.MODE_PRIVATE)

    var ratio: String
        get() = sp.getString("ratio", Ratio.FULL) ?: Ratio.FULL
        set(v) = sp.edit().putString("ratio", v).apply()

    var resolution: Int
        get() = sp.getInt("resolution", 1080)
        set(v) = sp.edit().putInt("resolution", v).apply()

    var fps: Int
        get() = sp.getInt("fps", 60)
        set(v) = sp.edit().putInt("fps", v).apply()

    var audio: String
        get() = sp.getString("audio", AudioMode.INTERNAL) ?: AudioMode.INTERNAL
        set(v) = sp.edit().putString("audio", v).apply()

    var customW: Int
        get() = sp.getInt("custom_w", 1080)
        set(v) = sp.edit().putInt("custom_w", v).apply()

    var customH: Int
        get() = sp.getInt("custom_h", 720)
        set(v) = sp.edit().putInt("custom_h", v).apply()

    var bubbleVisible: Boolean
        get() = sp.getBoolean("bubble_visible", true)
        set(v) = sp.edit().putBoolean("bubble_visible", v).apply()

    /** Bubble diameter in dp (36..90). */
    var bubbleSize: Int
        get() = sp.getInt("bubble_size", 56)
        set(v) = sp.edit().putInt("bubble_size", v).apply()

    /** Bubble opacity in percent (30..100). */
    var bubbleOpacity: Int
        get() = sp.getInt("bubble_opacity", 90)
        set(v) = sp.edit().putInt("bubble_opacity", v).apply()

    var hideWhileRecording: Boolean
        get() = sp.getBoolean("hide_while_rec", false)
        set(v) = sp.edit().putBoolean("hide_while_rec", v).apply()

    /** 0, 3 or 5 seconds. */
    var countdown: Int
        get() = sp.getInt("countdown", 3)
        set(v) = sp.edit().putInt("countdown", v).apply()

    /** "movies" or "dcim". */
    var saveLocation: String
        get() = sp.getString("save_location", "movies") ?: "movies"
        set(v) = sp.edit().putString("save_location", v).apply()

    /** "hi" or "en". */
    var lang: String
        get() = sp.getString("lang", "hi") ?: "hi"
        set(v) = sp.edit().putString("lang", v).apply()

    var bubbleX: Int
        get() = sp.getInt("bubble_x", -1)
        set(v) = sp.edit().putInt("bubble_x", v).apply()

    var bubbleY: Int
        get() = sp.getInt("bubble_y", -1)
        set(v) = sp.edit().putInt("bubble_y", v).apply()

    // ---------- Recording area (the movable box) ----------

    /** Ratio signature, so a saved box is only reused for the same ratio / custom size. */
    fun ratioSig(): String =
        if (ratio == Ratio.CUSTOM) "custom:${customW}x${customH}" else ratio

    /** Width / height of the selected ratio. */
    fun aspect(): Float = when (ratio) {
        Ratio.R916 -> 9f / 16f
        Ratio.R169 -> 16f / 9f
        Ratio.R11 -> 1f
        Ratio.R43 -> 4f / 3f
        Ratio.CUSTOM -> customW.toFloat() / customH.toFloat()
        else -> 1f
    }

    fun saveArea(r: Rect, screenW: Int, screenH: Int) {
        sp.edit()
            .putInt("a_l", r.left).putInt("a_t", r.top)
            .putInt("a_r", r.right).putInt("a_b", r.bottom)
            .putInt("a_sw", screenW).putInt("a_sh", screenH)
            .putString("a_sig", ratioSig())
            .apply()
    }

    /** Saved box for the current ratio and the current screen size, or null. */
    fun loadArea(screenW: Int, screenH: Int): Rect? {
        if (sp.getString("a_sig", "") != ratioSig()) return null
        if (sp.getInt("a_sw", 0) != screenW || sp.getInt("a_sh", 0) != screenH) return null
        val r = Rect(sp.getInt("a_l", 0), sp.getInt("a_t", 0), sp.getInt("a_r", 0), sp.getInt("a_b", 0))
        val ok = r.width() >= 50 && r.height() >= 50 && r.left >= 0 && r.top >= 0 &&
            r.right <= screenW && r.bottom <= screenH
        return if (ok) r else null
    }

    /** True when a box was saved for this ratio but for a different screen orientation/size. */
    fun areaStale(screenW: Int, screenH: Int): Boolean =
        sp.getString("a_sig", "") == ratioSig() &&
            (sp.getInt("a_sw", 0) != screenW || sp.getInt("a_sh", 0) != screenH)

    companion object {
        /** Default box: centred, about 80% of the screen, with the requested aspect. */
        fun defaultArea(aspect: Float, sw: Int, sh: Int, wantW: Int = 0, wantH: Int = 0): Rect {
            val maxW = sw * 0.8f
            val maxH = sh * 0.8f
            val w: Float
            val h: Float
            if (wantW > 0 && wantH > 0 && wantW <= maxW && wantH <= maxH) {
                w = wantW.toFloat(); h = wantH.toFloat()
            } else if (aspect >= maxW / maxH) {
                w = maxW; h = w / aspect
            } else {
                h = maxH; w = h * aspect
            }
            val l = ((sw - w) / 2f).toInt()
            val t = ((sh - h) / 2f).toInt()
            return Rect(l, t, l + w.toInt(), t + h.toInt())
        }
    }
}

object LocaleHelper {
    /** Returns a context whose resources use the language chosen inside the app. */
    fun wrap(base: Context): Context {
        val lang = Prefs(base).lang
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(Locale(lang))
        return base.createConfigurationContext(cfg)
    }
}

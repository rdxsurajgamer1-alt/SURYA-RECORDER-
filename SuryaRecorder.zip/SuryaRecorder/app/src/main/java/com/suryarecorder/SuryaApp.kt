package com.suryarecorder

import android.app.Application

class SuryaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                Prefs(this).lastError = ("CRASH: " + android.util.Log.getStackTraceString(e)).take(1800)
            } catch (x: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
    }
}

package com.suryarecorder

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

/** Invisible activity that only shows Android's "start recording?" permission dialog. */
class ProjectionActivity : Activity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            try {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                @Suppress("DEPRECATION")
                startActivityForResult(mpm.createScreenCaptureIntent(), 77)
            } catch (e: Exception) {
                sendFail()
                finish()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, SuryaService::class.java)
                    .setAction(SuryaService.ACTION_PROJ_OK)
                    .putExtra(SuryaService.EXTRA_CODE, resultCode)
                    .putExtra(SuryaService.EXTRA_DATA, data)
                startForegroundService(i)
            } else {
                sendFail()
            }
        }
        finish()
        overridePendingTransition(0, 0)
    }

    private fun sendFail() {
        startForegroundService(Intent(this, SuryaService::class.java).setAction(SuryaService.ACTION_PROJ_FAIL))
    }
}

package com.suryarecorder

import android.content.ContentValues
import android.content.Context
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Display
import android.view.Surface
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Screen recording engine.
 *
 * MediaProjection -> VirtualDisplay -> SurfaceTexture (OES) -> OpenGL (crop to the chosen box)
 * -> MediaCodec H.264 (input surface) -> MediaMuxer (MP4)
 * Audio: AudioPlaybackCapture (internal) and/or microphone -> mixed -> AAC -> same MP4.
 */
class ScreenRecorder(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val cfg: Config,
    private val listener: Listener
) {
    data class Config(
        val screenW: Int, val screenH: Int, val dpi: Int,
        val region: Rect,
        val plan: Plan,
        val audio: String,
        val saveToDcim: Boolean
    )

    data class Plan(
        val outW: Int, val outH: Int, val fps: Int, val bitrate: Int,
        val level: Int, val reqLevel: Int, val reqFps: Int,
        val resWarn: Boolean, val fpsWarn: Boolean,
        val encoderName: String?
    )

    interface Listener {
        fun onWarning(code: Int)
        fun onProjectionStopped()
        fun onFinished(uri: Uri?, name: String)
    }

    companion object {
        const val W_INTERNAL = 1
        const val W_MIC = 2
        const val W_NOAUDIO = 3

        private const val SAMPLE_RATE = 44100
        private const val MIME_VIDEO = "video/avc"

        fun levelName(l: Int): String = when (l) {
            2160 -> "4K (2160p)"
            1440 -> "2K (1440p)"
            1080 -> "1080p Full HD"
            720 -> "720p HD"
            else -> "${l}p"
        }

        fun maxRefresh(ctx: Context): Int {
            return try {
                val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                val d = dm.getDisplay(Display.DEFAULT_DISPLAY)
                val best = d?.supportedModes?.maxOfOrNull { it.refreshRate } ?: 60f
                best.roundToInt()
            } catch (e: Exception) {
                60
            }
        }

        fun pickEncoder(): MediaCodecInfo? {
            return try {
                val list = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { ci ->
                    ci.isEncoder && ci.supportedTypes.any { it.equals(MIME_VIDEO, true) }
                }
                list.firstOrNull { it.isHardwareAccelerated } ?: list.firstOrNull()
            } catch (e: Exception) {
                null
            }
        }

        /** Works out the real output size / FPS this phone can do for the wanted settings. */
        fun makePlan(ctx: Context, sw: Int, sh: Int, region: Rect, reqLevel: Int, reqFps: Int): Plan {
            val info = pickEncoder()
            val vc = try {
                info?.getCapabilitiesForType(MIME_VIDEO)?.videoCapabilities
            } catch (e: Exception) {
                null
            }
            val wa = max(2, vc?.widthAlignment ?: 2)
            val ha = max(2, vc?.heightAlignment ?: 2)
            val short = min(sw, sh)

            fun dims(level: Int): Pair<Int, Int> {
                val f = level.toDouble() / short
                val w = max(wa, (region.width() * f).roundToInt() / wa * wa)
                val h = max(ha, (region.height() * f).roundToInt() / ha * ha)
                return Pair(w, h)
            }

            val eff = min(reqLevel, short)
            var warn = eff < reqLevel
            val levels = (listOf(eff) + listOf(2160, 1440, 1080, 720, 480).filter { it < eff }).distinct()
            var chosen = levels.last()
            var dim = dims(chosen)
            for (l in levels) {
                val d = dims(l)
                if (vc == null || vc.isSizeSupported(d.first, d.second)) {
                    chosen = l; dim = d
                    break
                } else {
                    warn = true
                }
            }
            if (chosen != reqLevel) warn = true

            val maxCodec = try {
                vc?.getSupportedFrameRatesFor(dim.first, dim.second)?.upper?.toInt() ?: 60
            } catch (e: Exception) {
                30
            }
            val maxDisp = max(30, maxRefresh(ctx))
            var fps = min(reqFps, min(maxCodec, maxDisp))
            fps = max(15, fps)

            var br = (dim.first.toDouble() * dim.second * fps * 0.12).toLong()
                .coerceIn(2_000_000L, 80_000_000L).toInt()
            try {
                vc?.bitrateRange?.let { br = it.clamp(br) }
            } catch (e: Exception) {
            }
            return Plan(dim.first, dim.second, fps, br, chosen, reqLevel, reqFps, warn, fps < reqFps, info?.name)
        }
    }

    // ---------------------------------------------------------------- state
    private val main = Handler(Looper.getMainLooper())
    private val stopped = AtomicBoolean(false)
    @Volatile private var silent = false
    @Volatile private var stopping = false
    @Volatile private var audioStop = false
    @Volatile var paused = false
        private set
    @Volatile private var pausedTotalNs = 0L
    private var pauseStartNs = 0L
    @Volatile private var startNs = 0L

    private var resolver = ctx.contentResolver
    private var outUri: Uri? = null
    private var outName = ""
    private var pfd: ParcelFileDescriptor? = null
    private var muxer: MediaMuxer? = null
    private val muxLock = Any()
    private var videoTrack = -1
    private var audioTrack = -1
    private var muxStarted = false
    private var expectAudio = false

    private class Pending(val video: Boolean, val data: ByteArray, val info: MediaCodec.BufferInfo)

    private val pending = ArrayList<Pending>()

    // video
    private var vEncoder: MediaCodec? = null
    private var vInputSurface: Surface? = null
    private var vDrain: Thread? = null
    private var vDisplay: VirtualDisplay? = null
    private var projCb: MediaProjection.Callback? = null

    // GL
    private var glThread: HandlerThread? = null
    private var glHandler: Handler? = null
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var texId = 0
    private var surfaceTexture: SurfaceTexture? = null
    private var captureSurface: Surface? = null
    private var aPos = 0
    private var aTc = 0
    private var uTexMatrix = 0
    private val texMatrix = FloatArray(16)
    private lateinit var posBuf: FloatBuffer
    private lateinit var tcBuf: FloatBuffer
    @Volatile private var glReady = false
    private var hasFrame = false
    private var lastFramePts = -1_000_000_000L
    private var minIntervalNs = 0L

    // audio
    private var audioEnc: MediaCodec? = null
    private var internalRec: AudioRecord? = null
    private var micRec: AudioRecord? = null
    private var audioThread: Thread? = null
    private val audioInfo = MediaCodec.BufferInfo()

    // ---------------------------------------------------------------- public API

    @Throws(Exception::class)
    fun start() {
        openOutput()
        setupVideoEncoder()

        val t = HandlerThread("surya-gl")
        t.start()
        glThread = t
        glHandler = Handler(t.looper)
        minIntervalNs = (1_000_000_000.0 / cfg.plan.fps * 0.8).toLong()
        runOnGl {
            setupEgl(vInputSurface!!)
            setupGl()
        }

        setupAudio()

        startNs = System.nanoTime()
        projCb = object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { listener.onProjectionStopped() }
            }
        }
        projection.registerCallback(projCb!!, main)
        vDisplay = projection.createVirtualDisplay(
            "SuryaRecorder", cfg.screenW, cfg.screenH, cfg.dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            captureSurface, null, null
        )

        vDrain = Thread({ drainVideo() }, "surya-vdrain").also { it.start() }
        if (expectAudio) {
            audioThread = Thread({ audioLoop() }, "surya-audio").also { it.start() }
        }
    }

    fun pause() {
        if (paused || stopping) return
        pauseStartNs = System.nanoTime()
        paused = true
    }

    fun resume() {
        if (!paused || stopping) return
        pausedTotalNs += System.nanoTime() - pauseStartNs
        paused = false
        // Re-draw the last picture so a still screen continues right after resume.
        glHandler?.post {
            if (glReady && hasFrame && !stopping && !paused) {
                try { drawNow(true) } catch (e: Throwable) { }
            }
        }
    }

    fun elapsedMs(): Long {
        val end = if (paused) pauseStartNs else System.nanoTime()
        return max(0L, (end - startNs - pausedTotalNs) / 1_000_000L)
    }

    fun stop() {
        if (!stopped.compareAndSet(false, true)) return
        Thread({ finish() }, "surya-finish").start()
    }

    /** Stop and throw the file away without any callback (used when start() failed). */
    fun abort() {
        silent = true
        stop()
    }

    // ---------------------------------------------------------------- output file

    private fun openOutput() {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        outName = "SURYA_$stamp.mp4"
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, outName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(
                MediaStore.Video.Media.RELATIVE_PATH,
                if (cfg.saveToDcim) "DCIM/SuryaRecorder" else "Movies/SuryaRecorder"
            )
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            ?: throw IOException("Cannot create file")
        outUri = uri
        val p = resolver.openFileDescriptor(uri, "rw") ?: throw IOException("Cannot open file")
        pfd = p
        muxer = MediaMuxer(p.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    }

    // ---------------------------------------------------------------- video encoder

    private fun videoFormat(withVbr: Boolean): MediaFormat {
        val p = cfg.plan
        return MediaFormat.createVideoFormat(MIME_VIDEO, p.outW, p.outH).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, p.bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, p.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            if (withVbr) {
                setInteger(
                    MediaFormat.KEY_BITRATE_MODE,
                    MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
                )
            }
        }
    }

    private fun setupVideoEncoder() {
        var enc: MediaCodec? = null
        try {
            val name = cfg.plan.encoderName
            enc = if (name != null) MediaCodec.createByCodecName(name) else MediaCodec.createEncoderByType(MIME_VIDEO)
            enc.configure(videoFormat(true), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            try { enc?.release() } catch (x: Exception) { }
            enc = MediaCodec.createEncoderByType(MIME_VIDEO)
            enc.configure(videoFormat(false), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        }
        vInputSurface = enc!!.createInputSurface()
        enc.start()
        vEncoder = enc
    }

    private fun drainVideo() {
        val enc = vEncoder ?: return
        val info = MediaCodec.BufferInfo()
        while (true) {
            val idx = try {
                enc.dequeueOutputBuffer(info, 10_000)
            } catch (e: Exception) {
                break
            }
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                addFormat(true, enc.outputFormat)
            } else if (idx >= 0) {
                val buf = enc.getOutputBuffer(idx)
                if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                if (info.size > 0 && buf != null) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    writeSample(true, buf, info)
                }
                try { enc.releaseOutputBuffer(idx, false) } catch (e: Exception) { break }
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
            }
        }
    }

    // ---------------------------------------------------------------- muxer

    private fun addFormat(video: Boolean, fmt: MediaFormat) {
        synchronized(muxLock) {
            val m = muxer ?: return
            if (muxStarted) return
            try {
                if (video) videoTrack = m.addTrack(fmt) else audioTrack = m.addTrack(fmt)
                if (videoTrack >= 0 && (!expectAudio || audioTrack >= 0)) {
                    m.start()
                    muxStarted = true
                    for (p in pending) {
                        m.writeSampleData(if (p.video) videoTrack else audioTrack, ByteBuffer.wrap(p.data), p.info)
                    }
                    pending.clear()
                }
            } catch (e: Exception) {
            }
        }
    }

    private fun writeSample(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        synchronized(muxLock) {
            val m = muxer ?: return
            try {
                if (!muxStarted) {
                    val bytes = ByteArray(info.size)
                    buf.get(bytes)
                    val bi = MediaCodec.BufferInfo()
                    bi.set(0, info.size, info.presentationTimeUs, info.flags)
                    pending.add(Pending(video, bytes, bi))
                } else {
                    m.writeSampleData(if (video) videoTrack else audioTrack, buf, info)
                }
            } catch (e: Exception) {
            }
        }
    }

    // ---------------------------------------------------------------- OpenGL (crop)

    private fun runOnGl(block: () -> Unit) {
        val latch = CountDownLatch(1)
        var err: Throwable? = null
        glHandler!!.post {
            try { block() } catch (t: Throwable) { err = t }
            latch.countDown()
        }
        latch.await()
        err?.let { throw RuntimeException(it.message ?: it.toString(), it) }
    }

    private fun setupEgl(surface: Surface) {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) throw RuntimeException("No EGL display")
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, ver, 0, ver, 1)) throw RuntimeException("EGL init failed")
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            0x3142, 1, // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        EGL14.eglChooseConfig(eglDisplay, attribs, 0, configs, 0, 1, num, 0)
        if (num[0] <= 0 || configs[0] == null) throw RuntimeException("No EGL config")
        val ctxAttr = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(eglDisplay, configs[0], EGL14.EGL_NO_CONTEXT, ctxAttr, 0)
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, configs[0], surface, intArrayOf(EGL14.EGL_NONE), 0)
        if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) {
            throw RuntimeException("EGL makeCurrent failed")
        }
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Shader error: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun setupGl() {
        val vs = """
            uniform mat4 uTexMatrix;
            attribute vec4 aPos;
            attribute vec2 aTc;
            varying vec2 vTc;
            void main() {
                gl_Position = aPos;
                vTc = (uTexMatrix * vec4(aTc, 0.0, 1.0)).xy;
            }
        """.trimIndent()
        val fs = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTc;
            uniform samplerExternalOES sTex;
            void main() {
                gl_FragColor = texture2D(sTex, vTc);
            }
        """.trimIndent()
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(program, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(program)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("GL link failed")
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTc = GLES20.glGetAttribLocation(program, "aTc")
        uTexMatrix = GLES20.glGetUniformLocation(program, "uTexMatrix")

        // Crop: the chosen box (screen pixels, origin top-left) -> texture coordinates (origin bottom-left)
        val r = cfg.region
        val sw = cfg.screenW.toFloat()
        val sh = cfg.screenH.toFloat()
        val u0 = r.left / sw
        val u1 = r.right / sw
        val vTop = 1f - r.top / sh
        val vBot = 1f - r.bottom / sh
        val pos = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val tc = floatArrayOf(u0, vBot, u1, vBot, u0, vTop, u1, vTop)
        posBuf = ByteBuffer.allocateDirect(pos.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        posBuf.put(pos).position(0)
        tcBuf = ByteBuffer.allocateDirect(tc.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        tcBuf.put(tc).position(0)

        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        texId = tex[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val st = SurfaceTexture(texId)
        st.setDefaultBufferSize(cfg.screenW, cfg.screenH)
        st.setOnFrameAvailableListener({ onFrame() }, glHandler)
        surfaceTexture = st
        captureSurface = Surface(st)
        android.opengl.Matrix.setIdentityM(texMatrix, 0)
        glReady = true
    }

    private fun onFrame() {
        if (!glReady) return
        val st = surfaceTexture ?: return
        try {
            st.updateTexImage()
        } catch (e: Exception) {
            return
        }
        hasFrame = true
        st.getTransformMatrix(texMatrix)
        if (paused || stopping) return
        try { drawNow(false) } catch (t: Throwable) { }
    }

    private fun drawNow(force: Boolean) {
        var pts = System.nanoTime() - startNs - pausedTotalNs
        if (pts < 0) pts = 0
        if (!force && pts - lastFramePts < minIntervalNs) return
        if (pts <= lastFramePts) pts = lastFramePts + 1_000_000L
        lastFramePts = pts

        GLES20.glViewport(0, 0, cfg.plan.outW, cfg.plan.outH)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glUniformMatrix4fv(uTexMatrix, 1, false, texMatrix, 0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, posBuf)
        GLES20.glEnableVertexAttribArray(aTc)
        GLES20.glVertexAttribPointer(aTc, 2, GLES20.GL_FLOAT, false, 8, tcBuf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aTc)
        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, pts)
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    private fun releaseGl() {
        glReady = false
        try { captureSurface?.release() } catch (e: Exception) { }
        try { surfaceTexture?.release() } catch (e: Exception) { }
        try { if (program != 0) GLES20.glDeleteProgram(program) } catch (e: Exception) { }
        try {
            if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
                if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
                EGL14.eglTerminate(eglDisplay)
            }
        } catch (e: Exception) {
        }
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
    }

    // ---------------------------------------------------------------- audio

    private fun warn(code: Int) {
        main.post { listener.onWarning(code) }
    }

    private fun setupAudio() {
        val mode = cfg.audio
        val wantInternal = mode == AudioMode.INTERNAL || mode == AudioMode.BOTH
        val wantMic = mode == AudioMode.MIC || mode == AudioMode.BOTH
        if (!wantInternal && !wantMic) return

        if (wantInternal) {
            internalRec = createInternalRecord()
            if (internalRec == null) warn(W_INTERNAL)
        }
        if (wantMic) {
            micRec = createMicRecord()
            if (micRec == null) warn(W_MIC)
        }
        if (internalRec == null && micRec == null) {
            warn(W_NOAUDIO)
            return
        }
        try {
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            audioEnc = enc
            expectAudio = true
        } catch (e: Exception) {
            releaseRecord(internalRec); internalRec = null
            releaseRecord(micRec); micRec = null
            warn(W_NOAUDIO)
        }
    }

    private fun createInternalRecord(): AudioRecord? {
        return try {
            val apc = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            var buf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            ) * 4
            if (buf <= 0) buf = 32768
            val ar = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(buf)
                .setAudioPlaybackCaptureConfig(apc)
                .build()
            if (ar.state == AudioRecord.STATE_INITIALIZED) ar else { ar.release(); null }
        } catch (t: Throwable) {
            null
        }
    }

    @Suppress("MissingPermission")
    private fun createMicRecord(): AudioRecord? {
        return try {
            var buf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            ) * 4
            if (buf <= 0) buf = 16384
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf
            )
            if (ar.state == AudioRecord.STATE_INITIALIZED) ar else { ar.release(); null }
        } catch (t: Throwable) {
            null
        }
    }

    private fun releaseRecord(r: AudioRecord?) {
        try { r?.stop() } catch (e: Exception) { }
        try { r?.release() } catch (e: Exception) { }
    }

    private fun relUs(): Long = (System.nanoTime() - startNs - pausedTotalNs) / 1000L

    private fun clamp16(v: Int): Short = (if (v > 32767) 32767 else if (v < -32768) -32768 else v).toShort()

    private fun audioLoop() {
        val frames = 1024
        val inBuf = ShortArray(frames * 2)
        val micBuf = ShortArray(frames)
        val out = ShortArray(frames * 2)
        var base = relUs()
        var samples = 0L
        var wasPaused = false

        try { internalRec?.startRecording() } catch (e: Exception) {
            releaseRecord(internalRec); internalRec = null; warn(W_INTERNAL)
        }
        try { micRec?.startRecording() } catch (e: Exception) {
            releaseRecord(micRec); micRec = null; warn(W_MIC)
        }

        while (!audioStop) {
            var haveI = false
            var haveM = false

            val ir = internalRec
            if (ir != null) {
                val n = ir.read(inBuf, 0, inBuf.size, AudioRecord.READ_BLOCKING)
                if (n > 0) {
                    haveI = true
                    if (n < inBuf.size) java.util.Arrays.fill(inBuf, n, inBuf.size, 0.toShort())
                } else if (n < 0) {
                    releaseRecord(ir); internalRec = null; warn(W_INTERNAL)
                }
            }
            val mr = micRec
            if (mr != null) {
                val n = mr.read(micBuf, 0, micBuf.size, AudioRecord.READ_BLOCKING)
                if (n > 0) {
                    haveM = true
                    if (n < micBuf.size) java.util.Arrays.fill(micBuf, n, micBuf.size, 0.toShort())
                } else if (n < 0) {
                    releaseRecord(mr); micRec = null; warn(W_MIC)
                }
            }

            val noSource = internalRec == null && micRec == null
            if (!haveI && !haveM) {
                if (noSource) {
                    // Keep the audio track alive with silence (real-time paced).
                    java.util.Arrays.fill(out, 0.toShort())
                    try { Thread.sleep(23) } catch (e: InterruptedException) { }
                } else {
                    try { Thread.sleep(5) } catch (e: InterruptedException) { }
                    continue
                }
            } else {
                for (j in 0 until frames) {
                    var l = 0
                    var r = 0
                    if (haveI) { l += inBuf[2 * j]; r += inBuf[2 * j + 1] }
                    if (haveM) { val m = micBuf[j].toInt(); l += m; r += m }
                    out[2 * j] = clamp16(l)
                    out[2 * j + 1] = clamp16(r)
                }
            }

            if (paused) {
                wasPaused = true
                continue
            }
            if (wasPaused) {
                base = relUs()
                samples = 0
                wasPaused = false
            }
            val pts = base + samples * 1_000_000L / SAMPLE_RATE
            feedAudio(out, out.size, pts)
            samples += frames
        }

        // end of stream
        val enc = audioEnc
        if (enc != null) {
            try {
                var idx = -1
                var tries = 0
                while (idx < 0 && tries < 20) {
                    idx = enc.dequeueInputBuffer(50_000)
                    if (idx < 0) drainAudio()
                    tries++
                }
                if (idx >= 0) {
                    enc.queueInputBuffer(
                        idx, 0, 0, base + samples * 1_000_000L / SAMPLE_RATE,
                        MediaCodec.BUFFER_FLAG_END_OF_STREAM
                    )
                }
                val deadline = System.currentTimeMillis() + 2500
                while (System.currentTimeMillis() < deadline) {
                    if (drainAudio()) break
                    try { Thread.sleep(10) } catch (e: InterruptedException) { }
                }
            } catch (e: Exception) {
            }
        }
        releaseRecord(internalRec)
        releaseRecord(micRec)
    }

    private fun feedAudio(data: ShortArray, n: Int, ptsUs: Long) {
        val enc = audioEnc ?: return
        var off = 0
        var pts = ptsUs
        try {
            while (off < n && !audioStop) {
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx < 0) {
                    drainAudio()
                    continue
                }
                val ib = enc.getInputBuffer(idx) ?: return
                ib.clear()
                val cnt = min(n - off, ib.capacity() / 2)
                ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(data, off, cnt)
                enc.queueInputBuffer(idx, 0, cnt * 2, pts, 0)
                off += cnt
                pts += (cnt / 2) * 1_000_000L / SAMPLE_RATE
                drainAudio()
            }
        } catch (e: Exception) {
        }
    }

    /** Returns true when the end-of-stream marker has been reached. */
    private fun drainAudio(): Boolean {
        val enc = audioEnc ?: return true
        while (true) {
            val i = try {
                enc.dequeueOutputBuffer(audioInfo, 0)
            } catch (e: Exception) {
                return true
            }
            if (i == MediaCodec.INFO_TRY_AGAIN_LATER) return false
            if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                addFormat(false, enc.outputFormat)
            } else if (i >= 0) {
                val buf = enc.getOutputBuffer(i)
                if ((audioInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) audioInfo.size = 0
                if (audioInfo.size > 0 && buf != null) {
                    buf.position(audioInfo.offset)
                    buf.limit(audioInfo.offset + audioInfo.size)
                    writeSample(false, buf, audioInfo)
                }
                val eos = (audioInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                try { enc.releaseOutputBuffer(i, false) } catch (e: Exception) { return true }
                if (eos) return true
            }
        }
    }

    // ---------------------------------------------------------------- finish

    private fun finish() {
        stopping = true
        audioStop = true

        try { projCb?.let { projection.unregisterCallback(it) } } catch (e: Exception) { }
        try { vDisplay?.release() } catch (e: Exception) { }
        try { projection.stop() } catch (e: Exception) { }

        // Tell the encoder no more frames are coming, then free GL.
        if (glHandler != null) {
            try {
                runOnGl {
                    try { vEncoder?.signalEndOfInputStream() } catch (e: Exception) { }
                    releaseGl()
                }
            } catch (e: Exception) {
            }
        } else {
            try { vEncoder?.signalEndOfInputStream() } catch (e: Exception) { }
        }

        try { vDrain?.join(4000) } catch (e: Exception) { }
        try { audioThread?.join(5000) } catch (e: Exception) { }

        try { vEncoder?.stop() } catch (e: Exception) { }
        try { vEncoder?.release() } catch (e: Exception) { }
        try { vInputSurface?.release() } catch (e: Exception) { }
        try { audioEnc?.stop() } catch (e: Exception) { }
        try { audioEnc?.release() } catch (e: Exception) { }

        var ok = false
        synchronized(muxLock) {
            val m = muxer
            if (m != null) {
                if (muxStarted) {
                    try { m.stop(); ok = true } catch (e: Exception) { ok = false }
                }
                try { m.release() } catch (e: Exception) { }
            }
            muxer = null
        }
        try { pfd?.close() } catch (e: Exception) { }
        try { glThread?.quitSafely() } catch (e: Exception) { }

        val uri = outUri
        var resultUri: Uri? = null
        if (uri != null) {
            try {
                if (ok && !silent) {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    resolver.update(uri, v, null, null)
                    resultUri = uri
                } else {
                    resolver.delete(uri, null, null)
                }
            } catch (e: Exception) {
            }
        }
        if (!silent) {
            main.post { listener.onFinished(resultUri, outName) }
        }
    }
}
